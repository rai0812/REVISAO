﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PapaiNoel.Domain.Entidades
{
    public class Carta
    {
        public int Id { get; set; }
        public string NomeCrianca { get; set; }
        public string Endereco { get; set; }
        public int Idade { get; set; }
        public string TextoCarta { get; set; }


    }
}
