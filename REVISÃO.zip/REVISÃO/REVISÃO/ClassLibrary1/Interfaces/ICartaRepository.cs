﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PapaiNoel.Domain.Entidades;

namespace PapaiNoel.Domain.Interfaces
{
    public interface ICartaRepository
    {
        void Create(Carta carta);
        List<Carta> GetAll();
    }
}
