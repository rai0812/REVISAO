﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PapaiNoel.Data.Context;
using PapaiNoel.Domain.Entidades;
using PapaiNoel.Domain.Interfaces;

namespace PapaiNoel.Data.Repositories
{
    public class CartaRepository : ICartaRepository

    {
        private readonly AppDbContext_Context;
            public CartaRepository(AppDbContext context)
        {
            _context = context;
        }
        public void Create(Carta carta)
        {
            _context.Cartas.Add(carta);
            _context.SaveChanges();
        }
        public List<Carta> GetAll()
        {
            return_context.Cartas.ToList();
        }
    }

}
