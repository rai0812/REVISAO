﻿using Microsoft.AspNetCore.Mvc;
using PapaiNoel.Domain.Entidades;
using PapaiNoel.Application.Services;


namespace PapaiNoel.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CartasController : ControllerBase
    {
        private readonly CartaService _service;

        public CartasController(CartaService service)
        {
            _service = service;
        }

        [HttpPost]
        public IActionResult Post(Carta carta)
        {
            _service.EnviarCarta(carta);
            return Ok("Carta enviada com sucesso!");
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_service.Listar());
        }
    }
}