using Microsoft.EntityFrameworkCore;
using PapaiNoel.Data.Context;
using PapaiNoel.Data.Repositories;
using PapaiNoel.Domain.Interfaces;
using PapaiNoel.Application.Services;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


builder.Services.AddScoped<ICartaRepository, CartaRepository>();
builder.Services.AddScoped<CartaService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.Run();
