﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PapaiNoel.Domain.Entidades;
using PapaiNoel.Domain.Interfaces;

namespace PapaiNoel.Application.Services
{
    public class CartaService
    {
        private readonly ICartaRepository_repository;
            public CartaService(ICartaRepository repository)
        {
            _repository = repository;
        }
        public void EnviarCarta(Carta carta)
        {
            if (string.IsNullOrWhiteSpace(carta.NomeCrianca)
           || carta.NomeCrianca.Length < 3
           || carta.NomeCrianca.Length > 255)
                throw new Exception("Nome da criança inválido");

            if (carta.Idade > 15)
                throw new Exception("Idade máxima permitida é 15 anos");

            if (carta.TextoCarta.Length > 500)
                throw new Exception("Texto da carta muito longo");

            _repository.Create(carta);
        }

        public List<Carta> Listar()
        {
            return _repository.GetAll();
        }

    }
}
